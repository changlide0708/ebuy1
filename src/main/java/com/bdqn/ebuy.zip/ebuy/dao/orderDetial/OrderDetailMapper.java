package com.bdqn.ebuy.dao.orderDetial;

import com.bdqn.ebuy.pojo.OrderDetail;

/**
 * Created by hp on 2017/12/21.
 */
public interface OrderDetailMapper {
    Integer addOrderDetail(OrderDetail orderDetail);
}
