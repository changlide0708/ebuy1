package com.bdqn.ebuy.service.orderDetailService;

import com.bdqn.ebuy.pojo.OrderDetail;

/**
 * Created by hp on 2017/12/21.
 */
public interface OrderDetailService {
    Integer addOrderDetail(OrderDetail orderDetail);
}
